<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 h-screen flex justify-center items-center">
    <div class="bg-white p-8 rounded shadow-md w-96">
        <h2 class="text-2xl font-bold mb-6 text-gray-800">Login</h2>
        <form action="BackEnd/login.php" method="POST">
            <div class="mb-4">
                <label for="usuario" class="block text-gray-700">Usuario:</label>
                <input type="text" id="usuario" name="user" required class="w-full p-2 border rounded focus:outline-none focus:ring focus:border-blue-300">
            </div>
            <div class="mb-6">
                <label for="contrasena" class="block text-gray-700">Contraseña:</label>
                <input type="password" id="contrasena" name="pass" required class="w-full p-2 border rounded focus:outline-none focus:ring focus:border-blue-300">
            </div>
            <button type="submit" class="w-full bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-600">Entrar</button>
        </form>
    </div>
</body>
</html>

