<?php
// panel.php
include 'backend/connectDB.php';
session_start();
if (!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit;
}

// CRUD: Mostrar datos
$result = $conn->query("SELECT * FROM clients");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Panel de Administración</title>
    
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>
</head>
<body class="bg-gray-100 h-screen">

    <style>
        /* Estilo de los botones */
.btn-edit, .btn-addMail, .btn-delete {
    padding: 0.5rem 1rem;
    font-size: 0.875rem;
    font-weight: 500;
    border-radius: 0.375rem;
    transition: background-color 0.3s ease;
}

.btn-edit {
    background-color: #3b82f6;
    color: white;
}

.btn-edit:hover {
    background-color: #2563eb;
}

.btn-addMail {
    background-color: #10b981;
    color: white;
}

.btn-addMail:hover {
    background-color: #059669;
}

.btn-delete {
    background-color: #ef4444;
    color: white;
}

.btn-delete:hover {
    background-color: #dc2626;
}


      .btn-logout{
        width: 12%;
        float:right;
        background:gray;
        margin:20px;
      }

      table{
        background:white;
      }

      button{
        display:inline-flex !important;
      }

    .rightItems{
        width: 20%;

    }

    .rightItems button{
        float:right !important;
        margin-left:40px;
    }

    .mo_ma{
        width: 50% !important;
    }

    @media (max-width: 600px) {
        .mo_ma{
            width: 100% !important;
        }
        .deleteMailBTN{
            margin-top:1.5%;
        }
    }

    .innerMail{
        display:inline-block;
    }

    .deleteMailBTN{
        float:right;
        margin-right:2%;
    }

    .editMailBTN{
        float:right;
        margin-right:2%;       
    }

    .listMail{
        background:#f3f3f3;
        padding:15px;
        height:200px;
        overflow-y:scroll;
        border-radius:5px;
    }

    .nameClient{
        font-weight: 600;
    }

    .closeMailModal{
        float:right !important;
    }

    .responsiveModal{
        width: 100%;

    }

    </style>

    <a href="logout.php" class="btn-logout text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"><i class="fa-solid fa-arrow-right-from-bracket"></i></a>
    <div class="container mx-auto p-8">
    <h2 class="text-xl font-bold mt-8">Clientes</h2>

<!-- Buscador -->
<div class="mb-4">
    <input type="text" id="searchInput" class="w-full p-2 border border-gray-300 rounded-lg" placeholder="Buscar clientes...">
</div>

<!-- Tabla de Clientes -->
<table class="table-auto w-full border-collapse border border-gray-300 mt-4" id="clientsTable">
    <thead>
        <tr>
            <th class="border border-gray-300 px-4 py-2">Cliente</th>
            <th class="border border-gray-300 px-4 py-2">Telefono</th>
            <th class="border border-gray-300 px-4 py-2">Código</th>
            <th class="border border-gray-300 px-4 py-2">Acciones</th>
        </tr>
    </thead>
    <tbody>
        <!-- Los clientes se cargarán aquí mediante AJAX -->
    </tbody>
</table>

<!-- Paginación -->
<div id="pagination" class="mt-4 flex justify-center">
</div>

<script>

$(document).ready(function() {
    let currentPage = 1;
    const maxClientsPerPage = 10;

    function loadClients(page = 1, searchQuery = '') {
        $.ajax({
            url: 'backend/fetch_clients.php',
            type: 'GET',
            data: {
                page: page,
                limit: maxClientsPerPage,
                search: searchQuery
            },
            success: function(response) {
                const data = JSON.parse(response);

                let rows = '';
                data.clients.forEach(client => {
                    rows += `
                        <tr>
                            <td class="border border-gray-300 px-4 py-2" data-label="Usuario">${client.nameClient}</td>
                            <td class="border border-gray-300 px-4 py-2" data-label="Usuario">${client.phone}</td>
                            <td class="border border-gray-300 px-4 py-2" data-label="Código">${client.code}</td>
                            <td class="rightItems border border-gray-300 px-4 py-2 justify-right items-right " data-label="Acciones">
                                <button id-client="${client.id}" class="deleteClient btn-delete text-white bg-red-700 hover:bg-red-800" type="button" onclick="removeClient(${client.id})">
                                    <i class="fa-solid fa-trash"></i>
                                </button>
                                <button id-client="${client.id}" name-client="${client.nameClient}" class="my-2 sm:my-0 btn-edit text-white bg-blue-700 hover:bg-blue-800" type="button" data-toggle="modal" data-target="#popup-modal" onclick="editClient(${client.id})">
                                    <i class="fa-solid fa-pen"></i>
                                </button>
                                <button name-client="${client.nameClient}" id-client="${client.id}" class="btn-addMail text-white bg-green-700 hover:bg-green-800" type="button">
                                   <i class="fa-solid fa-list"></i>
                                </button>

                            </td>
                        </tr>
                    `;
                });

                $('#clientsTable tbody').html(rows);

                let pagination = '';
                for (let i = 1; i <= data.totalPages; i++) {
                    pagination += `
                        <button class="page-btn px-4 py-2 mx-1 ${i === page ? 'bg-blue-500 text-white' : 'bg-gray-200'}" data-page="${i}">
                            ${i}
                        </button>
                    `;
                }
                $('#pagination').html(pagination);
            }
        });
    }

    $('#searchInput').on('keyup', function() {
        const searchQuery = $(this).val();
        loadClients(currentPage, searchQuery); 
    });

    $(document).on('click', '.page-btn', function() {
        currentPage = $(this).data('page');
        const searchQuery = $('#searchInput').val();
        loadClients(currentPage, searchQuery); 
    });
    loadClients(currentPage);

    window.editClient = function(clientId) {
        $.ajax({
            url: 'backend/get_client_details.php',  
            type: 'GET',
            data: { id: clientId },
            success: function(response) {
                const client = JSON.parse(response);
                $('#userInput').val(client.nameClient);
                $('#mailInput').val(client.mail || '');
                $('#phoneInput').val(client.phone || '');
                $('#submitEditForm').data('client-id', client.id); 

                $('#popup-modal').removeClass('hidden');
            }
        });
    };

    $(document).on('click', '.deleteClient', function() {
        var idClient = $(this).attr("id-client");
        $('#popup-modal-delete').removeClass('hidden');

        $("#submitDeleteUser").click(function(e) {
                var data = {
                        id: idClient
                };
                console.log("eliminando el usuario con el siguiente ID: -> "+data);

                $.ajax({
                    url: "backend/delete.php",
                    type: "POST",
                    data: JSON.stringify(data),
                    contentType: "application/json",
                    success: function(response) {
                        currentPage = $(this).data('page');
                        const searchQuery = $('#searchInput').val();
                        loadClients(currentPage, searchQuery); 
                        $('#popup-modal-delete').addClass('hidden');
                    },
                    error: function() {
                        $("#messageDelete").html("<p class='text-red-500'>Hubo un error al eliminar el usuario.</p>");
                    }
                });
            })
    });

    $('#submitEditForm').click(function(e) {
        e.preventDefault();
        const clientId = $(this).data('client-id');
        const user = $('#userInput').val();
        const mail = $('#mailInput').val();
        const phone = $('#phoneInput').val();

        $.ajax({
            url: 'backend/edit.php', 
            type: 'POST',
            data: {
                id: clientId,
                nameClient: user,
                mail: mail,
                phone: phone
            },
            success: function(response) {
                loadClients(currentPage);  
                $('#popup-modal').addClass('hidden');  
            },
            error: function() {
                alert('Error al actualizar el cliente');
            }
        });
    });
});

</script>


<hr class="my-2 right">
<button id="openModal" class="bg-indigo-600 text-white py-2 px-6 rounded-lg hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-400 transition duration-300">
    Agregar Cliente
</button>

<div id="modal" style="background:#00010185;" class="fixed flex inset-0 bg-black bg-opacity-50 hidden justify-center items-center z-50">
    <div id="modalContent" class="bg-white p-6 rounded-lg w-full max-w-md transform transition-all opacity-0 scale-95">
        <h2 class="text-2xl font-semibold mb-6 text-gray-800 text-center">Agregar Cliente</h2>
        <form id="addUserForm" action="backend/create.php" method="POST">
            <div class="mb-5">
                <label for="usuario" class="block text-gray-700 text-sm font-medium">cliente *</label>
                <input type="text" id="usuario" name="user" required class="w-full p-3 mt-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-400">
            </div>

            <div class="mb-5">
                <label for="mail" class="block text-gray-700 text-sm font-medium">Correo</label>
                <input type="email" id="mail" name="mail" class="w-full p-3 mt-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-400">
            </div>

            <div class="mb-5">
                <label for="phone" class="block text-gray-700 text-sm font-medium">Teléfono</label>
                <input type="text" id="phone" name="phone" class=" p-3 mt-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-400">
            </div>

            <div class="flex justify-between items-center mt-6">
                <button type="submit" class="bg-green-700 text-white py-2 px-6 rounded-lg hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-400 w-ful sm:w-auto">
                    Agregar
                </button>
                <button id="closeModal" class="bg-red-700 text-white py-2 px-6 rounded-lg hover:bg-red-800 focus:outline-none focus:ring-2 focus:ring-green-400 w-ful sm:w-auto">Cerrar</button>
            </div>
        </form>
    </div>
</div>

<script>
    $(document).ready(function() {
        $("#openModal").click(function() {
            $("#modal").removeClass("hidden");
            $("#modalContent").removeClass("opacity-0 scale-95").addClass("opacity-100 scale-100");
        });

        $(document).on("click", "#closeModal", function() {
            $("#modalContent").removeClass("opacity-100 scale-100").addClass("opacity-0 scale-95");
            setTimeout(function() {
                $("#modalContent").html(`
                    <h2 class="text-2xl font-semibold mb-6 text-gray-800 text-center">Agregar cliente</h2>
                    <form id="addUserForm" action="backend/create.php" method="POST">
                    <div class="mb-5">
                        <label for="usuario" class="block text-gray-700 text-sm font-medium">cliente *</label>
                        <input type="text" id="usuario" name="user" required class="w-full p-3 mt-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-400">
                    </div>

                    <div class="mb-5">
                        <label for="mail" class="block text-gray-700 text-sm font-medium">Correo</label>
                        <input type="email" id="mail" name="mail" class="w-full p-3 mt-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-400">
                    </div>

                    <div class="mb-5">
                        <label for="phone" class="block text-gray-700 text-sm font-medium">Teléfono</label>
                        <input type="text" id="phone" name="phone" class=" p-3 mt-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-400">
                    </div>

                    <div class="flex justify-between items-center mt-6">
                        <button type="submit" class="bg-green-700 text-white py-2 px-6 rounded-lg hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-400 w-ful sm:w-auto">
                            Agregar
                        </button>
                        <button id="closeModal" class="bg-red-700 text-white py-2 px-6 rounded-lg hover:bg-red-800 focus:outline-none focus:ring-2 focus:ring-green-400 w-ful sm:w-auto">Cerrar</button>
                    </div>
                </form>
                `);
            }, 200);
            setTimeout(function() {
                $("#modal").addClass("hidden");
            }, 200);
        });

        $(document).on("click", "#closeModalEdit", function() {
            $("#modalContent").removeClass("opacity-100 scale-100").addClass("opacity-0 scale-95");
            $("#popup-modal").addClass("hidden");
        });
        $("body").on("submit", "#addUserForm", function(e) {
           e.preventDefault(); 
            var formData = $(this).serialize();

            $.ajax({
                url: "backend/create.php",
                type: "POST",
                data: formData,
                success: function(response) {
                    $("#modalContent").html(`
                        <h2 class="text-2xl font-semibold mb-6 text-gray-800 text-center">Código de Cliente</h2>
                        <p class="text-lg text-gray-700 text-center mb-6">Código: ${response}</p>
                        <div class="flex justify-center mt-6">
                            <button id="closeModal" class="bg-indigo-600 text-white py-2 px-6 rounded-lg hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-400">
                                Cerrar
                            </button>
                        </div>
                    `);
                },
                error: function() {
                    alert("Error al agregar usuario. Intenta de nuevo.");
                }
            });
        });
    });
</script>




    </div>

<!-- Modal de Edición -->
<div id="popup-modal" tabindex="-1" style="background:#00010185;" class="fixed flex inset-0 bg-black bg-opacity-50 hidden justify-center items-center z-50">
    <div class="relative p-4 w-full max-w-md max-h-full">
        <div class="relative bg-white rounded-lg shadow dark:bg-gray-700">
            <div class="p-4 md:p-5 text-center">
                <svg class="mx-auto mb-4 text-gray-400 w-12 h-12 dark:text-gray-200" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 20">
                    <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 11V6m0 8h.01M19 10a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z"/>
                </svg>

                <h2 id="message" class="text-xl font-bold mt-8">Editar cliente</h2>
                        <div class="mb-4">
                            <label for="usuario" class="block text-gray-700">cliente</label>
                            <input type="text" id="userInput" name="user" required class="w-full p-2 border rounded">
                        </div>

                        <div class="mb-4">
                            <label for="mail" class="block text-gray-700">Correo</label>
                            <input type="mail" id="mailInput" name="mail" class="w-full p-2 border rounded">
                        </div>

                        <div class="mb-4">
                            <label for="phone" class="block text-gray-700">Teléfono</label>
                            <input type="text" id="phoneInput" name="phone" class="w-full p-2 border rounded">
                        </div>

                        <button id="submitEditForm" class="bg-green-500 text-white py-2 px-4 rounded hover:bg-green-600">Guardar</button>
                        <button id="closeModalEdit" class="bg-red-700 text-white py-2 px-6 rounded-lg hover:bg-red-800 focus:outline-none focus:ring-2 focus:ring-green-400 w-ful sm:w-auto"    >Cerrar</button>
                </div>
            </div>
        </div>
    </div>
</div>

  <!--modal Delete-->

<div id="popup-modal-delete" tabindex="-1" style="background:#00010185;" class="fixed flex inset-0 bg-black bg-opacity-50 hidden justify-center items-center z-50">
    <div class="relative p-4 w-full max-w-md max-h-full">
        <div class="relative bg-white rounded-lg shadow dark:bg-gray-700">
            <div class="p-4 md:p-5 text-center">
                <svg class="mx-auto mb-4 text-gray-400 w-12 h-12 dark:text-gray-200" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 20">
                    <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 11V6m0 8h.01M19 10a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z"/>
                </svg>

                <h2 id="messageDelete" class="text-xl font-bold mt-8">Estas seguro que deseas eliminar este cliente?</h2>
                    <button id="submitDeleteUser" class="bg-green-500 text-white py-2 px-4 rounded hover:bg-green-600">si eliminar!</button>
                    <button id="closeModalDelete" class="bg-red-700 text-white py-2 px-6 rounded-lg hover:bg-red-800 focus:outline-none focus:ring-2 focus:ring-green-400 w-ful sm:w-auto">Cancelar</button>
                </div>
            </div>
        </div>
    </div>
</div>                

<div id="modal-mails" style="background:#00010185;" class="fixed flex inset-0 bg-black bg-opacity-50 hidden justify-center items-center z-50">
    <div id="modalContent" class="mo_ma bg-white p-6 rounded-lg transform transition-all opacity-1     scale-95">
        <!-- Formulario inicial -->
        <h2 class="text-2xl font-semibold mb-6 text-gray-800 text-center">Gestionar cuentas</h2>
        <div id="Mails"></div>
    </div>
</div>

<div id="modal-editMail" style="background:#00010185;" class="fixed flex inset-0 bg-black bg-opacity-50 hidden justify-center items-center z-50">
    <div id="modalContent" class="bg-white p-6 rounded-lg w-full max-w-md transform transition-all opacity-1     scale-95">
    <h2 class="text-2xl font-semibold mb-6 text-gray-800 text-center">Editar correo</h2>

        <div class="mb-4">
            <label for="mail" class="block text-gray-700">Editar Correo</label>
            <input type="mail" id="mailEditNew" name="mail" class="w-full p-2 border rounded">
        </div>
        <br>
        <button class="editMailArrow bg-green-500 text-white py-2 px-4 rounded hover:bg-green-600">Guardar</button>
        <button id="closeModalSendMailAdd" class="closeMailEditModal bg-red-700 text-white py-2 px-6 rounded-lg hover:bg-red-800 focus:outline-none focus:ring-2 focus:ring-green-400 w-ful sm:w-auto">Cancelar</button>
    </div>
</div>

<script>

        $(document).on('click', '.openModalSendMailAdd', function() {
            var idClient = $(this).attr("id-client");
            $('#modal-mails-add').removeClass('hidden');
        })

        $(document).on("click", "#closeModalSendMailAdd", function() {
            $("#modal-mails-add").addClass("hidden");
        });

        $(document).on("click", "#closeModalDelete", function() {
            $("#popup-modal-delete").addClass("hidden");
        });

        $(document).on("click", "#closeModalAdminMails", function() {
            $("#modal-mails").addClass("hidden");
        });

        $(document).on("click", ".closeMailEditModal", function() {
            $("#modal-editMail").addClass("hidden");
        });

        $(document).on("click", ".openModalSendMailAddTextArea", function() {
            $("#modal-mails-add-textArea").removeClass("hidden");
        });

        $(document).on("click", "#closeModalSendMailAdd-textArea", function() {
            $("#modal-mails-add-textArea").addClass("hidden");
        });
        
        $(document).on("click", ".deleteMailBTN", function() {
            var idMail = $(this).attr("id-mail");
            var idClient = $(this).attr("id-client");
            var data = {
                id: idMail
            };
            var nameClient = $("#clientName").text()
            $("#popup-modal-deleteMAil").removeClass("hidden");
            
            $(document).on("click", "#submitDeleteMail", function() {
                $.ajax({
                    url: "backend/deleteMail.php",
                    type: "POST",
                    data: JSON.stringify(data),
                    contentType: "application/json",
                    success: function(response) {
                        searchMailUser(idClient,nameClient)
                        console.log(response)
                    },
                    error: function() {
                        $("#messageDelete").html("<p class='text-red-500'>Hubo un error al eliminar el usuario.</p>");
                    }
                });
            });

            $(document).on("click", "#closeModalDeleteMail", function() {
                $("#popup-modal-deleteMAil").addClass("hidden");
            });
        });

        $(document).on("click", ".arrowMailList", function() {
            var idClient = $(this).attr("id-client");
            var listMails = $("#mailList").val()
            var data = {
                id: idClient,
                mailList: listMails
            };
            var nameClient = $("#clientName").text()

            $.ajax({
                url: "backend/addMailList.php",
                type: "POST",
                data: JSON.stringify(data),
                contentType: "application/json",
                success: function(response) {
                    searchMailUser(idClient,nameClient)
                    console.log(response)
                },
                error: function() {
                    $("#messageDelete").html("<p class='text-red-500'>Hubo un error al eliminar el usuario.</p>");
                }
            });
        });

        $(document).on("click", ".arrowMail", function() {
            var idClient = $(this).attr("id-client");
            var newMail = $("#mailAddNew").val();
            var nameClient = $("#clientName").text()
            var data = {
                id: idClient,
                mail: newMail
            };

            $.ajax({
                url: "backend/addMail.php",
                type: "POST",
                data: JSON.stringify(data),
                contentType: "application/json",
                success: function(response) {
                    searchMailUser(idClient, nameClient)
                    console.log(response)
                },
                error: function() {
                    $("#messageDelete").html("<p class='text-red-500'>Hubo un error al eliminar el usuario.</p>");
                }
            });
        });

        function searchMailUser(idUser, nameClient){
            var data = {
                    id: idUser,
                    nameClient: nameClient
            };

            $("#modal-mails").removeClass("hidden");

            $.ajax({
                url: "backend/serachMails.php",
                type: "POST",
                data: JSON.stringify(data), 
                contentType: "application/json",
                success: function(response) {
                    $("#Mails").html(response);
                },
                error: function() {
                    $("#messageDelete").html("<p class='text-red-500'>Hubo un error al eliminar el usuario.</p>");
                }
            });
        }
        
        $(document).on("click", ".btn-addMail", function() {
            var idClient = $(this).attr("id-client");
            var nameClient = $(this).attr("name-client");
            searchMailUser(idClient, nameClient)
        });


        var idMail;
        var idClient, dataMail;

        $(document).on('click', '.callEditMail', function() {
            idClient = $(this).attr("id-client");
            dataMail = $(this).attr("data-mail");
            $("#mailEditNew").val(dataMail);
            idMail = $(this).attr("id-mail")

            $('#modal-editMail').removeClass('hidden');
        });

        $(document).on('click', '.editMailArrow', function() {
                var newData = $("#mailEditNew").val();
                var data = {
                        idMail: idMail,
                        mail: newData
                };
                var nameClient = $("#clientName").text();

                $.ajax({
                    url: "backend/editMail.php",
                    type: "POST",
                    data: JSON.stringify(data),
                    contentType: "application/json",
                    success: function(response) {
                        console.log(response)
                        $('#modal-editMail').addClass('hidden');
                        searchMailUser(idClient, nameClient)
                        $("#mailEditNew").val()
                    },
                    error: function() {
                        $("#messageDelete").html("<p class='text-red-500'>Hubo un error al eliminar el usuario.</p>");
                    }
                });
        })
        $("button").click(function() {
            var idClient = $(this).attr("id-client");

            $("#submitEditForm").on("click",function(e) {
                
                var nameClient = $("#userInput").val();
                var mailClient = $("#mailInput").val();
                var phoneClient = $("#phoneInput").val();
                var data = {
                        name: nameClient,
                        mail: mailClient,
                        phone: phoneClient,
                        id: idClient
                };

                e.preventDefault();
                console.log(data);
                $.ajax({
                    url: "backend/edit.php",
                    type: "POST",
                    data: JSON.stringify(data),
                    contentType: "application/json",
                    success: function(response) {
                        $("#message").html("<p class='text-green-500'>Usuario editado correctamente.</p>");
                        console.log(response)
                    },
                    error: function() {
                        $("#message").html("<p class='text-red-500'>Hubo un error al editar el usuario.</p>");
                    }
                });
            });

        });
    </script>
</body>
</html>