<?php
include 'connectDB.php';

$inputJSON = file_get_contents("php://input"); 
$data = json_decode($inputJSON, true); 

if ($data) {

    $id = $data['idMail'];
    $idMail = intval($id);
    $mail = $data['mail'];

    $stmt = $conn->prepare("UPDATE mails SET mail = ? WHERE id = ?");
    $stmt->bind_param('si', $mail, $idMail);
    $stmt->execute();

    echo "ready edit";
} else {
    echo "asdasas asdasd";
}
?>