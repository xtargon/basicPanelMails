<?php
include 'connectDB.php';

$inputJSON = file_get_contents("php://input"); 
$data = json_decode($inputJSON, true); 

if ($_POST) {

    $id = $_POST['id'];
    $userNameClient = $_POST['nameClient'];
    $mail = $_POST['mail'];
    $phone = $_POST['phone'];

    $stmt = $conn->prepare("UPDATE clients SET nameClient = ?, mail = ?, phone = ? WHERE id = ?");
    $stmt->bind_param('sssi', $userNameClient, $mail, $phone, $id);
    $stmt->execute();


} else {
  
}
?>

