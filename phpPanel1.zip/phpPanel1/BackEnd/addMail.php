<?php
include 'connectDB.php';

$inputJSON = file_get_contents("php://input"); 
$data = json_decode($inputJSON, true); 

if ($data) {
    $idUser = $data['id'];
    $mailNew = $data['mail'];

    echo $data['id'];
    echo '        ';
    echo $data['mail'];
    echo '   ';


    $stmt = $conn->prepare("INSERT INTO mails (mail, id_user) VALUES (?, ?)");
    $stmt->bind_param('ss', $mailNew, $idUser);
    $stmt->execute();


} else {
    echo $data['mail'];
}
?>