<?php
// Conexion a la base de datos
require_once('connectDB.php');

// Obtener parámetros de la solicitud AJAX
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
$search = isset($_GET['search']) ? '%' . $_GET['search'] . '%' : '%';

// Calcular el desplazamiento (offset) para la paginación
$offset = ($page - 1) * $limit;

// Consulta para obtener los clientes con búsqueda y paginación
$sql = "SELECT id, nameClient, code, phone FROM clients WHERE nameClient LIKE ? OR code LIKE ? OR phone LIKE ? OR mail LIKE ? LIMIT ?, ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssssii", $search, $search, $search, $search, $offset, $limit);
$stmt->execute();
$result = $stmt->get_result();

// Obtener el total de clientes para la paginación
$sqlCount = "SELECT COUNT(*) as total FROM clients WHERE nameClient LIKE ? OR code LIKE ?";
$stmtCount = $conn->prepare($sqlCount);
$stmtCount->bind_param("ss", $search, $search);
$stmtCount->execute();
$countResult = $stmtCount->get_result();
$totalClients = $countResult->fetch_assoc()['total'];
$totalPages = ceil($totalClients / $limit);

// Obtener los resultados y preparar la respuesta
$clients = [];
while ($row = $result->fetch_assoc()) {
    $clients[] = $row;
}

// Responder con los clientes y la información de paginación
echo json_encode([
    'clients' => $clients,
    'totalPages' => $totalPages
]);

?>
