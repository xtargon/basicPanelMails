<?php
// create.php
include 'connectDB.php';
$mail = " ";
$phone = " ";

function codeGenerator($longitud = 4) {
    // Definir el conjunto de caracteres permitidos (números y letras)
    $caract = '0123456789';
    $code = '';
    $max = strlen($caract) - 1;

    // Generar un código de longitud especificada
    for ($i = 0; $i < $longitud; $i++) {
        $code .= $caract[random_int(0, $max)];
    }

    return $code;
}

$codex = codeGenerator();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = $_POST['user'];
    
    if($_POST['mail'] !== ""){
        $mail = $_POST['mail'];
    }
    if($_POST['phone'] !== ""){
        $phone = $_POST['phone'];
    }
    

    $stmt = $conn->prepare("INSERT INTO clients (nameClient, mail, phone, code) VALUES (?, ?, ?, ?)");
    $stmt->bind_param('ssss', $user, $mail, $phone, $codex);
    $stmt->execute();

    //header('Location: ../dashboard.php');
    //exit;
    echo $codex;
}
?>