<?php
include 'connectDB.php';

$inputJSON = file_get_contents("php://input"); 
$data = json_decode($inputJSON, true); 

if ($data) {
    $id = $data['id'];

    $stmt = $conn->prepare("DELETE FROM mails WHERE id = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();

    header("Content-Type: text/plain");
    echo "Datos recibidos:\n";

    echo "eliminar ID: " . $data['id'];

} else {
    // En caso de error con el JSON
    header("Content-Type: text/plain");
    echo "No se recibieron datos válidos o el JSON está mal formado.";
}
?>