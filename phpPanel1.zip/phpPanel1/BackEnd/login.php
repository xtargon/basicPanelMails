<?php
// BackEnd php
include 'connectDB.php';
echo "hola mundo";
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    session_start();

    $user = $_POST['user'];
    $pass = $_POST['pass'];

    $stmt = $conn->prepare("SELECT * FROM users WHERE user = ?");
    $stmt->bind_param('s', $user);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $row = $result->fetch_assoc();
        if (password_verify($pass, $row['pass'])) {
            $_SESSION['user'] = $user;
            header('Location: ../dashboard.php');
            exit;
        } else {
            echo "<p>Contraseña incorrecta.</p>";
        }
    } else {
        echo "<p>Usuario no encontrado.</p>";
    }
}
?>
