<?php
include 'connectDB.php';

$inputJSON = file_get_contents("php://input"); 
$data = json_decode($inputJSON, true); 

if ($data) {
    $idUser = $data['id'];
    $mailsNew = $data['mailList'];

    echo $data['id'];
    echo '        ';
    echo $data['mailList'];
    echo '   ';

    $elements = explode("\n", $mailsNew);
    $stmt = $conn->prepare("INSERT INTO mails (mail, id_user) VALUES (?, ?)");

    foreach ($elements as $line) {

        $stmt->bind_param('ss', $line, $idUser);
        $stmt->execute();
        echo "este es un mail procesado -> ".$line . "\n";
    }


} else {
    echo $data['mail'];
}
?>