<?php
include 'connectDB.php';

$inputJSON = file_get_contents("php://input"); 
$data = json_decode($inputJSON, true); 
//$clientID = $_POST['id'];
//var_dump($data);
if ($data["id"]) {

    $id = $data["id"];
    $result = $conn->query("SELECT * FROM mails WHERE id_user = $id");
    echo "<h4 class='nameClient' id='clientName'>".$data['nameClient']."</h4>";

    echo    '<div class="listMail">
                    ';
                    while ($row = $result->fetch_assoc()) {
                        echo '
                            <h5 class="innerMail">'.$row['mail'].'</h5>
                                <button id-client="'.$id.'" id-mail="'.$row['id'].'" class=" deleteMailBTN btn-delete-mail text-white bg-red-700 hover:bg-red-800 focus:ring-4 focus:outline-none focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-red-600 dark:hover:bg-red-700 dark:focus:ring-red-800" type="button">
                                    <i class="fa-solid fa-trash"></i>
                                </button> 
                                <button id="callEditMail" id-client="'.$id.'" data-mail="'.$row['mail'].'" id-mail="'.$row['id'].'" class="callEditMail editMailBTN my-2 sm:my-0 btn-edit text-white bg-blue-700 hover:bg-blue-800" type="button" data-toggle="modal" data-target="#popup-modal">
                                    <i class="fa-solid fa-pen"></i>
                                </button>
                                <br>
                                <br>                    
                        ';
                    }
                    echo ' 
            </div>
            <br>
            <button id-client="'.$id.'" class="openModalSendMailAdd bg-green-500 text-white py-2 px-4 rounded hover:bg-green-600">Agregar correo</button>
            <button id-client="'.$id.'" class="openModalSendMailAddTextArea bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-600">Agregar lista correo</button>
            <button id="closeModalAdminMails" class="closeMailModal bg-red-700 text-white py-2 px-6 rounded-lg hover:bg-red-800 focus:outline-none focus:ring-2 focus:ring-green-400 w-ful sm:w-auto">Cancelar</button>
           
            <div id="modal-mails-add" style="background:#00010185;" class="fixed flex inset-0 bg-black bg-opacity-50 hidden justify-center items-center z-50">
                <div id="modalContent" class="bg-white p-6 rounded-lg w-full max-w-md transform transition-all opacity-1     scale-95">
                    <div class="mb-4">
                        <label for="mail" class="block text-gray-700">Correo</label>
                        <input type="mail" id="mailAddNew" name="mail" class="w-full p-2 border rounded">
                    </div>
                    <br>
                    <button id-client="'.$id.'" class="arrowMail bg-green-500 text-white py-2 px-4 rounded hover:bg-green-600">Agregar</button>
                    <button id="closeModalSendMailAdd" class="closeMailModal bg-red-700 text-white py-2 px-6 rounded-lg hover:bg-red-800 focus:outline-none focus:ring-2 focus:ring-green-400 w-ful sm:w-auto">Cancelar</button>
                </div>
            </div>

            <div id="modal-mails-add-textArea" style="background:#00010185;" class="fixed flex inset-0 bg-black bg-opacity-50 hidden justify-center items-center z-50">
                <div id="modalContent" class="bg-white p-6 rounded-lg w-full max-w-md transform transition-all opacity-1     scale-95">
                    <div class="mb-4">
                        <label for="mailList" id="mailAddNewList" name="mailList" class="w-full p-2 border rounded">Lista de Correos</label>
                        <textarea name="textarea" rows="10" id="mailList" cols="50"></textarea>
                    </div>
                    <br>
                    <button id-client="'.$id.'" class="arrowMailList bg-green-500 text-white py-2 px-4 rounded hover:bg-green-600">Agregar Lista</button>
                    <button id="closeModalSendMailAdd-textArea" class="closeMailModalTextArea bg-red-700 text-white py-2 px-6 rounded-lg hover:bg-red-800 focus:outline-none focus:ring-2 focus:ring-green-400 w-ful sm:w-auto">Cancelar</button>
                </div>
            </div>

            <div id="popup-modal-deleteMAil" tabindex="-1" style="background:#00010185;" class="fixed flex inset-0 bg-black bg-opacity-50 hidden justify-center items-center z-50">
                <div class="relative p-4 w-full max-w-md max-h-full">
                    <div class="relative bg-white rounded-lg shadow dark:bg-gray-700">
                        <div class="p-4 md:p-5 text-center">
                            <svg class="mx-auto mb-4 text-gray-400 w-12 h-12 dark:text-gray-200" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 20">
                                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 11V6m0 8h.01M19 10a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z"/>
                            </svg>

                            <h2 id="messageDelete" class="text-xl font-bold mt-8">Estas seguro que deseas eliminar este Correo?</h2>
                                <button id="submitDeleteMail" class="bg-green-500 text-white py-2 px-4 rounded hover:bg-green-600">si eliminar!</button>
                                <button id="closeModalDeleteMail" class="bg-red-700 text-white py-2 px-6 rounded-lg hover:bg-red-800 focus:outline-none focus:ring-2 focus:ring-green-400 w-ful sm:w-auto">Cancelar</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>  

            ';

} else {
    // En caso de error con el JSON
    header("Content-Type: text/plain");
    echo "No se recibieron datos válidos o el JSON está mal formado.";
}
?>
