<?php
// Configuración de la conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$database = "phpPanel1";

// Crear la conexión
$conn = new mysqli($servername, $username, $password, $database);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Obtener el ID del cliente desde la solicitud
if (isset($_GET['id'])) {
    $clientId = (int)$_GET['id'];

    // Consulta para obtener los detalles del cliente
    $query = "SELECT id, nameClient, code, mail, phone FROM clients WHERE id = ?";

    // Preparar la consulta
    if ($stmt = $conn->prepare($query)) {
        // Vincular el parámetro (id) a la consulta
        $stmt->bind_param("i", $clientId);

        // Ejecutar la consulta
        $stmt->execute();

        // Obtener los resultados
        $result = $stmt->get_result();

        // Verificar si el cliente existe
        if ($result->num_rows > 0) {
            // Obtener los detalles del cliente como un arreglo asociativo
            $client = $result->fetch_assoc();
            // Retornar los datos del cliente en formato JSON
            echo json_encode($client);
        } else {
            // Si el cliente no existe
            echo json_encode(['error' => 'Cliente no encontrado']);
        }

        // Cerrar la declaración
        $stmt->close();
    } else {
        // Si la preparación de la consulta falla
        echo json_encode(['error' => 'Error en la consulta']);
    }
} else {
    // Si no se proporciona el ID
    echo json_encode(['error' => 'ID del cliente no proporcionado']);
}

// Cerrar la conexión
$conn->close();
?>
