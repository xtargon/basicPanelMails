<?php
// Conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$database = "phpPanel1";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Crear la tabla de usuarios si no existe
$sql = "CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user VARCHAR(50) NOT NULL,
    pass VARCHAR(255) NOT NULL
);";
$conn->query($sql);

// Registrar usuario por defecto si no existe
$sql = "SELECT * FROM users WHERE user = 'admin'";
$result = $conn->query($sql);
if ($result->num_rows === 0) {
    echo "hello world";
    $hashed_password = password_hash('admin*73', PASSWORD_DEFAULT);
    $conn->query("INSERT INTO users (user, pass) VALUES ('admin', '$hashed_password')");
}
?>